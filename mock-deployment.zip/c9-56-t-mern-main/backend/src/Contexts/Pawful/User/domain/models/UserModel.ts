interface UserModel {
  id: string
  email: string
  avatar: string
  passwordHash: string
  roleId: string
}

export { type UserModel }
