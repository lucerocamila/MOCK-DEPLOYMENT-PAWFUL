interface CategoryModel {
  id: string
  name: string
  description: string
}

export { type CategoryModel }
