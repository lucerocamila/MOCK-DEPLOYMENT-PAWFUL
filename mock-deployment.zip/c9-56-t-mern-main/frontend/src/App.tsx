

function App() {

  return (
    <div className="App">
     <h1 className="text-lime-600">Hello World</h1>
     
    </div>
  )
}

export default App
