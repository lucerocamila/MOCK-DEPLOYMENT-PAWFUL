interface PerfilModel {
  id: string
  name: string
  lastname: string
  image: string
  userId: string
  phone: string
  address: string
  titleCareer: string[]
}

export { type PerfilModel }
